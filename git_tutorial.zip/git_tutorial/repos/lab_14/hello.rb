name = ARGV.first || "World"

puts "Hello, #{name}!"
